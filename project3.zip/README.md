### High Level Approach
We constantly run the router in a while loop listening for messages it receives using the select method. After the router detects that a message has been received, we handled that message based on the type of the message (update, withdraw, data, dump). We have instance variables for our router to keep track of state such as relations (keeps track of relations of neighbors), sockets, ports, forwarding_table, update_announcements, and revocation_announcements. We decided to store the forwarding table as a dictionary of lists. Each key value of the dictionary is a network that maps to a list of networks that that network can send messages to. 

### Challenges
One of the challenges that we faced was determining if routes were numerically adjacent to each other. We decide to check if the binary strings of those routes were different at exactly one bit and made sure that it was at the subnet mask length where this differed. Aggregating also posed a challenge because we had to recursively aggregate sometimes when the newly aggregated route can further aggregate with other routes. We also dealt with problems with mutation where the update announcement lists were the same objects stored in the forwarding table so we had to create copies of them to prevent this mutation.

### Properties and Features of our Design
Lots of helper methods to reuse code such as bit string to binary maniputation and getting the number of bits in an IP address. We wrote a lot of comments to explain each step in our program. We organized the functionality well with our handle_message_type() method.

### Tests
To test our program, we used a lot of print statements to see what the values of our variables were at a given time. We also went through each test case configuration, figured out the expected output and tried to compare it with what our program was outputting. 